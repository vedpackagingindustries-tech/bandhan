#!/bin/bash
set -euo pipefail
echo "=== Bandhan v1.0.0 — Production Build ==="
bun install
bunx prisma generate
bun run build
echo "=== Build complete. Run ./start-production.sh to serve. ==="
