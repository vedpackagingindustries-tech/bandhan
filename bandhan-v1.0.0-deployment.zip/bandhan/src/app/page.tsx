'use client'

import { useState, useEffect, useCallback } from 'react'
import dynamic from 'next/dynamic'
import { TopInfoBar } from '@/components/layout/TopInfoBar'
import { Header } from '@/components/layout/Header'
import { Footer } from '@/components/layout/Footer'
import { HeroAdvertisement } from '@/components/home/HeroAdvertisement'
import { TopShowcase } from '@/components/home/TopShowcase'
import { LiveCommunityActivity } from '@/components/home/LiveCommunityActivity'
import { ModuleGrid } from '@/components/home/ModuleGrid'
import { PremiumAdBanner } from '@/components/home/PremiumAdBanner'
import { FeaturedCommunityContent } from '@/components/home/FeaturedCommunityContent'
import { FooterAdvertisement } from '@/components/home/FooterAdvertisement'
import { PremiumStats } from '@/components/home/PremiumStats'
import { FeaturedProfiles } from '@/components/home/FeaturedProfiles'
import { ModulePageView, type ModuleKey } from '@/components/modules/ModulePageView'
import { MyAccountView } from '@/components/account/MyAccountView'
import { SuperAdminPanel } from '@/components/admin/SuperAdminPanel'

// Dynamic import for BrandIntro to avoid blocking initial render
const BrandIntro = dynamic(
  () => import('@/components/home/BrandIntro').then((m) => ({ default: m.BrandIntro })),
  { ssr: false }
)

const validModules: ModuleKey[] = ['matrimony', 'business', 'jobs', 'directory']

export default function Home() {
  const [activeModule, setActiveModule] = useState<ModuleKey | null>(() => {
    if (typeof window === 'undefined') return null
    const hash = window.location.hash.replace('#', '')
    return validModules.includes(hash as ModuleKey) ? (hash as ModuleKey) : null
  })
  const [showAdmin, setShowAdmin] = useState(() => {
    if (typeof window === 'undefined') return false
    return window.location.hash.replace('#', '') === 'admin'
  })
  const [showAccount, setShowAccount] = useState(() => {
    if (typeof window === 'undefined') return false
    return window.location.hash.replace('#', '') === 'account'
  })

  // Hash-based routing - subscribe to changes only
  useEffect(() => {
    const onHashChange = () => {
      const hash = window.location.hash.replace('#', '')
      if (hash === 'admin') {
        setShowAdmin(true)
        setActiveModule(null)
        setShowAccount(false)
      } else if (hash === 'account') {
        setShowAccount(true)
        setActiveModule(null)
        setShowAdmin(false)
      } else if (validModules.includes(hash as ModuleKey)) {
        setActiveModule(hash as ModuleKey)
        setShowAdmin(false)
        setShowAccount(false)
      } else {
        setActiveModule(null)
        setShowAdmin(false)
        setShowAccount(false)
      }
    }
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  const goHome = useCallback(() => {
    window.location.hash = ''
    setActiveModule(null)
    setShowAdmin(false)
    setShowAccount(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [])

  // Super Admin Panel
  if (showAdmin) {
    return <SuperAdminPanel onBack={goHome} />
  }

  // My Account (payments / subscriptions / favourites)
  if (showAccount) {
    return <MyAccountView onBack={goHome} />
  }

  // Module page view
  if (activeModule) {
    return <ModulePageView module={activeModule} onBack={goHome} />
  }

  // Homepage
  return (
    <div className="flex min-h-screen flex-col">
      {/* First-Visit Brand Intro Overlay */}
      <BrandIntro />

      {/* Top Information Bar */}
      <TopInfoBar />

      {/* Premium Header with Flag */}
      <Header />

      <main className="flex-1">
        {/* 1. Large Spacious Hero Advertisement */}
        <HeroAdvertisement />

        {/* 1.5 Monthly Top 10 Premium Showcase (2-day window) */}
        <TopShowcase />

        {/* 2. Live Community Activity */}
        <LiveCommunityActivity />

        {/* 3. 2x2 Main Module Grid */}
        <ModuleGrid />

        {/* 4. Premium Middle Advertisement */}
        <div className="mx-auto max-w-7xl px-4 pt-3 sm:px-6 sm:pt-4">
          <PremiumAdBanner slideIndex={1} />
        </div>

        {/* 5. Featured Community Content (Mata Karma + Flag) */}
        <FeaturedCommunityContent />

        {/* 6. Real Community Stats */}
        <PremiumStats />

        {/* 7. Featured Profiles from Database */}
        <FeaturedProfiles />

        {/* 8. Large Spacious Footer Advertisement */}
        <FooterAdvertisement />
      </main>

      {/* White/Ivory Premium Footer */}
      <Footer />
    </div>
  )
}