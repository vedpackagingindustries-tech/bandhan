#!/bin/bash
set -euo pipefail
echo "=== Bandhan v1.0.0 — Production Start ==="
echo "[1/4] Installing dependencies..."
bun install --production 2>&1 | tail -1
echo "[2/4] Generating Prisma client..."
bunx prisma generate 2>&1 | tail -1
echo "[3/4] Running database setup..."
bun run db:push 2>&1 | tail -3
echo "[4/4] Starting production server..."
NODE_ENV=production bun .next/standalone/server.js
